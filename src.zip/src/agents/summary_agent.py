"""
Trip Summarizer Agent - Creates a comprehensive trip plan from all gathered information.
"""

from agents.base_agent import Agent


def create_summary_agent() -> Agent:
    """Create and return the Trip Summarizer agent"""
    return Agent(
        name="Trip Summarizer",
        description="Creates a comprehensive trip plan from all gathered information",
        system_prompt="""You are an AI agent specializing in trip planning and summarization.
        
Your task is to create a comprehensive trip plan by combining and synthesizing information about:
1. Flights and transportation
2. Accommodations
3. Attractions and activities

Create a day-by-day itinerary that makes logical sense, considering:
- Travel times between locations
- A reasonable pace of activities
- Balance between scheduled activities and free time
- Practical considerations like check-in/check-out times
- Budget considerations

Format your response as a clear, well-organized travel plan with daily sections.
Be specific where possible but avoid making up exact details that weren't provided.
Add helpful travel tips and packing suggestions relevant to the destination and activities."""
    )