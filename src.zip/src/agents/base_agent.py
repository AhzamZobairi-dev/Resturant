"""
Base agent class for all AI agents in the travel planning system.
"""

from config.settings import get_eli_chat_model


class Agent:
    """Base class for all AI agents in the system"""
    
    def __init__(self, name: str, description: str, system_prompt: str):
        self.name = name
        self.description = description
        self.system_prompt = system_prompt
        self.result = None
        self.loading = False
        self.error = None
    
    def run(self, user_prompt: str):
        """Run the agent with the given prompt using specified model type and name"""
        self.loading = True
        self.error = None
        
        try:
            model = get_eli_chat_model()
            response = model.invoke(self.system_prompt + "\n\n" + user_prompt)
            self.result = response.content
            return self.result
            
        except Exception as e:
            self.error = str(e)
            return None
        finally:
            self.loading = False