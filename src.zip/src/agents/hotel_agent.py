"""
Hotel Explorer Agent - Finds suitable accommodations at the destination.
"""

from agents.base_agent import Agent


def create_hotel_agent() -> Agent:
    """Create and return the Hotel Explorer agent"""
    return Agent(
        name="Hotel Explorer",
        description="Finds suitable accommodations at your destination within budget",
        system_prompt="""You are an AI agent specializing in finding hotel and accommodation information.
        
Your task is to provide realistic hotel options at a given destination within a specified budget range.
Include details such as:
- Variety of hotel types (luxury, mid-range, budget)
- Approximate price ranges
- Popular neighborhoods or areas to stay
- Amenities typically available
- Pros and cons of different areas
- Any seasonal considerations

Format your response in a clear, easy-to-read manner with sections.
Base your information on general knowledge about typical accommodations in the area.
DO NOT make up specific hotel names, exact prices, or claim to know real-time availability."""
    )