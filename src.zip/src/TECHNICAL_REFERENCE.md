# Technical Reference - Smart Itinerary

## Quick Module Reference

### 🏠 **main.py** - Application Entry Point
- **Purpose**: Streamlit app initialization and main flow control
- **Key Functions**:
  - `main()`: Entry point, renders UI and handles form submission
  - `process_trip_planning()`: Orchestrates trip generation process
- **Dependencies**: All UI modules, core TravelPlanner

### 🤖 **agents/** - AI Agent System

#### **base_agent.py**
- **Class**: `Agent(name, description, system_prompt)`
- **Key Method**: `run(user_prompt)` - Executes AI query via LangChain
- **Handles**: Error management, loading states, AI model communication

#### **Specialized Agents**
- **flight_agent.py**: `create_flight_agent()` - Flight search specialist
- **hotel_agent.py**: `create_hotel_agent()` - Accommodation finder
- **attraction_agent.py**: `create_attraction_agent()` - Activity discovery
- **summary_agent.py**: `create_summary_agent()` - Itinerary coordinator

### ⚙️ **config/settings.py** - Configuration Hub
- **`get_eli_chat_model()`**: LangChain ChatOpenAI setup with custom API
- **Constants**:
  - `MODEL_OPTIONS`: UI dropdown choices for AI models
  - `INTEREST_OPTIONS`: Travel preference categories
  - `MODEL_TYPE_MAP`: Maps UI selections to internal model types

### 🧠 **core/travel_planner.py** - Business Logic
- **Class**: `TravelPlanner()` 
- **Key Method**: `generate_trip_plan(trip_details)` - Main orchestration
- **Process**:
  1. Initialize all 4 agents
  2. Create base prompt from user input
  3. Run agents sequentially (flight → hotel → attraction → summary)
  4. Package results with error handling

### 🎨 **ui/** - User Interface Components

#### **styles.py**
- **`apply_custom_styles()`**: CSS injection for app styling
- **`render_header()`**: Main title and subtitle display

#### **forms.py**  
- **`render_sidebar()`**: AI model selection and configuration
- **`render_trip_form()`**: Main input form for trip details

#### **display.py**
- **Display Functions**: `display_*_info()` for each agent result
- **`display_example_content()`**: Initial app state content

## Technology Stack Deep Dive

### 🔗 **LangChain Integration**
```python
# Model Setup
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="sk-U0j3wCTfzxbPPxEZKQDE2g"
)

# Usage Pattern
response = llm.invoke(system_prompt + user_prompt)
result = response.content
```

### 🎨 **Streamlit Architecture**
```python
# UI Components
st.set_page_config()      # App configuration
st.form()                 # Input forms
st.tabs()                 # Result organization
st.download_button()      # File downloads
st.markdown()             # Content display
```

### 🔄 **Data Flow**
```
User Input → Form Validation → TravelPlanner → Agent Orchestration → 
AI API Calls → Result Aggregation → UI Display → Download Generation
```

## Key Design Patterns

### 🏗️ **Modular Architecture**
- **Separation of Concerns**: UI, Business Logic, Configuration isolated
- **Agent Pattern**: Specialized AI components for domain expertise
- **Configuration Centralization**: All settings in dedicated module

### 🔌 **Dependency Injection**
- Agents receive dependencies (model config) rather than creating them
- UI components import display logic rather than embedding it
- Main app coordinates but doesn't implement details

### 🛡️ **Error Handling**
- Agent-level error capture and reporting
- Graceful degradation (show partial results if some agents fail)
- User-friendly error messages in UI

## Extension Points

### 🆕 **Adding New Agents**
1. Create new agent file in `agents/`
2. Follow `base_agent.py` pattern
3. Add to `agents/__init__.py`
4. Integrate in `core/travel_planner.py`
5. Add display component in `ui/display.py`

### 🎨 **UI Customization**
- Modify `ui/styles.py` for visual changes
- Update `config/settings.py` for option lists
- Extend `ui/forms.py` for new input fields

### ⚙️ **Model Integration**
- Update `config/settings.py` for new AI providers
- Modify `get_eli_chat_model()` for different model configurations
- Add new model types to `MODEL_OPTIONS` and `MODEL_TYPE_MAP`

## Performance Considerations

### 🚀 **Optimization Opportunities**
- **Parallel Agent Execution**: Run non-dependent agents simultaneously
- **Caching**: Store common responses to reduce API calls
- **Streaming**: Display partial results as agents complete
- **Rate Limiting**: Manage API usage for cost control

### 📊 **Monitoring Points**
- Agent execution times
- API call success rates
- User session metrics
- Error frequencies by component