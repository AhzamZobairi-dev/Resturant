# Architecture & Data Flow - Smart Itinerary

This document explains the application's architecture and data flow in clear, actionable terms so developers (including beginners) can understand how components interact, what data moves where, and how to test/extend the system.

## Goals
- Describe the high-level architecture and components
- Show the data flow from user action to final output
- List component contracts (inputs/outputs, error modes)
- Provide testing guidance and recommended next steps

---

## High-Level Architecture

Components:

- UI (Streamlit)
  - Files: `main.py`, `ui/styles.py`, `ui/forms.py`, `ui/display.py`
  - Responsibilities: collect user input, show progress, display results, trigger business logic
- Core Orchestrator
  - Files: `core/travel_planner.py`
  - Responsibilities: create base prompt, coordinate agents, aggregate results
- Agents
  - Files: `agents/base_agent.py`, `agents/flight_agent.py`, `agents/hotel_agent.py`, `agents/attraction_agent.py`, `agents/summary_agent.py`
  - Responsibilities: run domain-specific prompts against the AI model and return structured responses
- Configuration
  - Files: `config/settings.py`
  - Responsibilities: model connection, constants, dropdown options
- External Systems
  - OpenAI (or other AI providers) via LangChain/OpenAI clients

Relationships:
- `main.py` imports UI components and the `TravelPlanner` from `core/`.
- UI gathers user data and calls `TravelPlanner.generate_trip_plan()`.
- `TravelPlanner` calls specialized agents in `agents/` which each interact with the external AI model via the function `get_eli_chat_model()` in `config/settings.py`.
- Results are returned to `main.py` which displays them via `ui/display.py` and offers a download.

---

## Data Flow (Textual Diagram)

1. User fills the trip form in the browser (Streamlit UI) and clicks "Tune My Travel".
2. Streamlit collects inputs into a `trip_details` dict and calls `process_trip_planning(trip_details)`.
3. `process_trip_planning` creates a `TravelPlanner` instance and calls `generate_trip_plan(trip_details)`.
4. `TravelPlanner.create_base_prompt(trip_details)` returns a prompt string containing origin, destination, duration, cost, and interests.
5. `TravelPlanner` sequentially runs:
   - `flight_agent.run(prompt)` → returns `flight_result`
   - `hotel_agent.run(prompt_with_budget)` → returns `hotel_result`
   - `attraction_agent.run(prompt_with_interests)` → returns `attraction_result`
6. After collecting agent outputs, `TravelPlanner.run_summary_agent(...)` calls the summary agent with concatenated agent outputs to synthesize `summary_result`.
7. `TravelPlanner` composes a `trip_plan_text` (Markdown) and a response dict containing results and any agent-level errors.
8. `process_trip_planning` receives the result and uses `ui/display.py` functions to show each result in a separate tab and provides a download via `st.download_button`.

---

## Component Contracts

Each component exposes a small contract: inputs, outputs, success, and error behavior.

### UI Components (`ui/*.py`)
- Input: none (reads from Streamlit widgets) or receives structured results to display
- Output: returns `trip_details` dict from form
- Success: Returns user inputs as expected
- Failure: Streamlit handles exceptions; user sees an error message via `st.error()`

Expected `trip_details` shape:

```python
{
  'origin': 'New York',
  'destination': 'Tokyo',
  'duration': '7',
  'cost': '1000000',
  'interests': ['Heritage & Culture', ...],
  'submitted': True
}
```

### TravelPlanner (`core/travel_planner.py`)
- Input: `trip_details` dict
- Output: dict containing `flight_result`, `hotel_result`, `attraction_result`, `summary_result`, `trip_plan_text`, and `errors` dict
- Success: Returns coherent text results for each agent and `summary_result`
- Failure: If an agent throws, the planner captures agent.error and continues (best-effort aggregation)

Errors returned in `errors` are agent-specific strings or `None`.

### Agents (`agents/*.py`)
- Input: prompt string (system prompt + user prompt)
- Output: string (agent's textual response) or `None` on error
- Success: `response.content` text
- Failure: Set `self.error` and return `None`

Agent-specific error modes:
- Network error to AI API
- Authentication error (invalid API key)
- Rate limit or timeout
- Unexpected response format

### Config (`config/settings.py`)
- Responsible for creating the AI client via `get_eli_chat_model()`
- Any issues here (bad API key) will surface as agent errors

---

## Sequence Diagram (Step-by-step)

1. User hits the page → Streamlit serves the UI
2. User submits form → `main.process_trip_planning(trip_details)`
3. `TravelPlanner.generate_trip_plan()` starts
4. For each agent:
   a. `agent.run(prompt)` calls `get_eli_chat_model()`
   b. `get_eli_chat_model()` returns a configured `ChatOpenAI` client
   c. `client.invoke(prompt)` → gets `response`
   d. `agent.run()` returns `response.content`
5. After all agents finish, the summary agent runs with combined text
6. `TravelPlanner` returns aggregated results
7. UI displays results and generates a downloadable Markdown file

---

## Error Handling and Recovery

- Agents capture their own exceptions; `TravelPlanner` collects agent-level errors in the `errors` dict.
- `process_trip_planning` displays any agent error alongside the other results.
- The summary agent runs even if one or two agent results are missing; it should make a best effort to synthesize what it has.

Common errors & guidance:
- **Network/API errors**: Check API keys and provider status
- **Invalid response**: Retry or provide fallback text in the UI
- **Streamlit UI errors**: Look at the terminal logs where Streamlit is running (it prints exceptions)

---

## Testing Guidance

### Unit tests (recommended):
- Mock `get_eli_chat_model()` to return a fake object that returns deterministic responses
- Test `Agent.run()` behavior with a mocked client
- Test `TravelPlanner.generate_trip_plan()` with mocked agent outputs

### Integration tests:
- Use a small script to call `TravelPlanner.generate_trip_plan()` with sample `trip_details`
- Validate `errors` is empty and results are non-empty strings

### Manual tests:
- Start Streamlit: `streamlit run main.py`
- Fill sample form data and run end-to-end
- Inspect tabbed results and download output

---

## Recommended Next Steps (engineering)

- Add automated tests (unittest/pytest) with mocked AI responses
- Add caching for repeated queries (e.g., same origin/destination)
- Consider executing independent agents in parallel to reduce latency
- Add better monitoring/logging for API call durations and errors

---

## Appendix: Quick Troubleshooting

- Ensure you're in the `src` directory before running Streamlit
- If imports fail, verify `__init__.py` files exist
- If AI calls fail, verify API keys in `config/settings.py` and network connectivity

---

If you'd like, next I can:
- Create simple unit tests scaffolding (pytest) and a mock for the AI client
- Draw a visual diagram (ASCII or Mermaid) showing the data flow
- Add runtime logging for agent latencies and errors