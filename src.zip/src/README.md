# AI Travel Planner - Modular Structure

This project has been restructured into a modular architecture for better maintainability and organization.

## Project Structure

```
src/
├── main.py                 # Main Streamlit application entry point
├── travel_old.py          # Backup of original monolithic file
├── agents/                # AI agent modules
│   ├── __init__.py
│   ├── base_agent.py      # Base Agent class
│   ├── flight_agent.py    # Flight search agent
│   ├── hotel_agent.py     # Hotel search agent
│   ├── attraction_agent.py # Attraction discovery agent
│   └── summary_agent.py   # Trip summarization agent
├── config/                # Configuration and settings
│   ├── __init__.py
│   └── settings.py        # Model configuration and constants
├── core/                  # Core business logic
│   ├── __init__.py
│   └── travel_planner.py  # Main TravelPlanner orchestrator
└── ui/                    # User interface components
    ├── __init__.py
    ├── styles.py          # CSS styling and header
    ├── forms.py           # Input forms and sidebar
    └── display.py         # Result display components
```

## Features

- **Modular Architecture**: Separated concerns into logical modules
- **Agent-Based System**: Individual AI agents for different travel aspects
- **Clean UI Components**: Separate modules for styling, forms, and display
- **Centralized Configuration**: All settings and model configuration in one place
- **No Functionality Changes**: All original features preserved

## Usage

Run the application the same way as before:

```bash
streamlit run main.py
```

## Modules Overview

### Agents (`agents/`)
- **base_agent.py**: Base class for all AI agents
- **flight_agent.py**: Handles flight search and recommendations
- **hotel_agent.py**: Manages hotel and accommodation search
- **attraction_agent.py**: Discovers attractions and activities
- **summary_agent.py**: Creates comprehensive trip summaries

### Configuration (`config/`)
- **settings.py**: Contains model setup, API configuration, and constants

### Core (`core/`)
- **travel_planner.py**: Main orchestrator that coordinates all agents

### UI (`ui/`)
- **styles.py**: CSS styling and header rendering
- **forms.py**: Input forms and sidebar configuration
- **display.py**: Results display and example content

## Benefits of Modular Structure

1. **Maintainability**: Easier to modify specific components
2. **Testability**: Individual modules can be tested in isolation
3. **Reusability**: Components can be reused across different interfaces
4. **Scalability**: Easy to add new agents or UI components
5. **Separation of Concerns**: Clear boundaries between different functionalities

## Development

To add new features:

1. **New Agent**: Create a new file in `agents/` following the base_agent pattern
2. **UI Changes**: Modify appropriate files in `ui/` directory
3. **Configuration**: Update `config/settings.py` for new settings
4. **Core Logic**: Extend `core/travel_planner.py` for new orchestration logic