import streamlit as st
import datetime
from core import TravelPlanner
from ui import (
    apply_custom_styles,
    render_header,
    render_sidebar,
    render_trip_form,
    display_flight_info,
    display_hotel_info,
    display_attraction_info,
    display_trip_summary,
    display_example_content
)

# Set page configuration
st.set_page_config(
    page_title="Travel Planner",
    page_icon="✈️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Apply custom styles
apply_custom_styles()

# Process trip planning
def process_trip_planning(trip_details):
    """Process trip planning with all agents"""
    try:
        # Initialize the travel planner with the selected model type
        planner = TravelPlanner()
        
        # Show progress indicators
        progress_container = st.empty()
        progress_container.info("Your adventure is in the works… hold tight for just a minute or two!.")
        
        # Generate the trip plan
        results = planner.generate_trip_plan(trip_details)
        
        # Clear progress indicator
        progress_container.empty()
        
        # Show results in tabs
        st.header("Your Itinerary Plan")
        tabs = st.tabs(["Flights", "Hotels", "Attractions", "Complete Trip Plan"])
        
        with tabs[0]:
            display_flight_info(results['flight_result'], results['errors']['flight_error'])
        
        with tabs[1]:
            display_hotel_info(results['hotel_result'], results['errors']['hotel_error'])
        
        with tabs[2]:
            display_attraction_info(results['attraction_result'], results['errors']['attraction_error'])
        
        with tabs[3]:
            display_trip_summary(results['summary_result'], results['errors']['summary_error'])
        
        # Add download button for the trip plan
        st.download_button(
            label="Download Itinerary Plan",
            data=results['trip_plan_text'],
            file_name=f"trip_plan_{trip_details['destination']}_{trip_details['duration']}_{trip_details['cost']}.md",
            mime="text/markdown"
        )
        
    except Exception as e:
        st.error(f"An error occurred: {str(e)}")

# Main app function
def main():
    """Main app function"""
    render_header()
    # api_key, model_type = render_sidebar()
    trip_details = render_trip_form()
    
    if trip_details['submitted']:
        process_trip_planning(trip_details)
    # else:
        # display_example_content()

if __name__ == "__main__":
    main()