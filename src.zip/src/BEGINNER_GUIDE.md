# Smart Itinerary - Complete Beginner's Guide

## Table of Contents
1. [Project Overview](#project-overview)
2. [Technologies Used](#technologies-used)
3. [Project Structure](#project-structure)
4. [Module-by-Module Explanation](#module-by-module-explanation)
5. [How Everything Works Together](#how-everything-works-together)
6. [Key Concepts for Beginners](#key-concepts-for-beginners)
7. [Running the Application](#running-the-application)

## Project Overview

**Smart Itinerary** is an AI-powered travel planning application that helps users create complete trip plans. The app uses multiple AI "agents" (specialized AI assistants) to handle different aspects of travel planning:

- 🛫 **Flight Finder**: Searches for flight options
- 🏨 **Hotel Explorer**: Finds accommodation recommendations  
- 🏛️ **Attraction Scout**: Discovers attractions and activities
- 📝 **Trip Summarizer**: Combines everything into a day-by-day itinerary

## Technologies Used

### 1. **Streamlit** 🎨
- **What it does**: Creates the web user interface (the webpage you interact with)
- **Why we use it**: Makes it easy to build interactive web apps with Python
- **In our app**: Handles forms, buttons, displays results, sidebar configuration

### 2. **LangChain** 🔗
- **What it does**: Framework for building AI applications that work with language models
- **Why we use it**: Simplifies connecting to AI models and managing conversations
- **In our app**: Handles communication with the AI model that powers our agents

### 3. **OpenAI API** 🤖
- **What it does**: Provides access to powerful AI language models
- **Why we use it**: The "brain" that generates travel recommendations
- **In our app**: Powers all four AI agents with intelligent responses

### 4. **Python** 🐍
- **What it does**: The programming language everything is written in
- **Why we use it**: Great for AI applications, web development, and data processing
- **In our app**: All the logic, AI integration, and web interface code

## Project Structure

```
src/
├── main.py                 # 🏠 Main entry point - starts the app
├── travel_old.py          # 📦 Backup of original code
├── main_old.py           # 📦 Backup of original main file
├── README.md             # 📖 Project documentation
├── BEGINNER_GUIDE.md     # 📚 This guide!
├── agents/               # 🤖 AI Agent modules
│   ├── __init__.py
│   ├── base_agent.py
│   ├── flight_agent.py
│   ├── hotel_agent.py
│   ├── attraction_agent.py
│   └── summary_agent.py
├── config/               # ⚙️ Configuration and settings
│   ├── __init__.py
│   └── settings.py
├── core/                 # 🧠 Main business logic
│   ├── __init__.py
│   └── travel_planner.py
└── ui/                   # 🎨 User interface components
    ├── __init__.py
    ├── styles.py
    ├── forms.py
    └── display.py
```

## Module-by-Module Explanation

### 📁 **main.py** - The Application Entry Point
```python
# This is where everything starts!
```

**What it does:**
- Starts the Streamlit web application
- Imports all the UI components and core logic
- Coordinates the main application flow
- Handles user interactions (form submissions, button clicks)

**Key Functions:**
- `main()`: The main function that runs when you start the app
- `process_trip_planning()`: Takes user input and generates the trip plan

**For Beginners:**
Think of this as the "front desk" of a hotel - it greets users and directs them to the right services.

---

### 📁 **agents/** - The AI Specialists

#### **base_agent.py** - The Foundation
```python
class Agent:
    def __init__(self, name, description, system_prompt):
        # Sets up the agent with its specialty
    
    def run(self, user_prompt):
        # Talks to the AI and gets a response
```

**What it does:**
- Defines the basic structure all agents share
- Handles communication with the AI model
- Manages errors and loading states

**For Beginners:**
Like a job description template that all travel specialists use - it defines what every agent should be able to do.

#### **flight_agent.py** - The Flight Specialist
**What it does:**
- Specializes in finding flight information
- Has specific instructions (prompts) for flight-related queries
- Returns flight options, prices, and travel advice

**System Prompt Example:**
```
"You are an AI agent specializing in finding flight information...
Include details such as:
- Airline options
- Approximate flight times and durations
- Price ranges..."
```

#### **hotel_agent.py** - The Accommodation Expert
**What it does:**
- Focuses on hotels and accommodations
- Considers budget, location, and amenities
- Provides neighborhood recommendations

#### **attraction_agent.py** - The Activity Guide
**What it does:**
- Discovers attractions and activities
- Matches suggestions to user interests
- Provides cultural and entertainment options

#### **summary_agent.py** - The Trip Coordinator
**What it does:**
- Takes information from all other agents
- Creates a day-by-day itinerary
- Considers practical logistics and timing

**For Beginners:**
Each agent is like a specialized travel consultant. Just like you might talk to different experts for flights vs hotels in real life, our app has different AI experts for each aspect.

---

### 📁 **config/** - The Settings Hub

#### **settings.py** - Configuration Central
```python
def get_eli_chat_model():
    # Sets up connection to the AI model

MODEL_OPTIONS = ["Claude (Anthropic)", "GPT-4o (OpenAI)", "Gemini 1.5 (Google)"]
INTEREST_OPTIONS = ["Heritage & Culture", "Nature Escapes", ...]
```

**What it does:**
- Stores all configuration settings in one place
- Sets up the AI model connection
- Defines dropdown options for the user interface
- Contains API keys and connection details

**For Beginners:**
Like a control panel where you adjust all the app's settings. Instead of scattered settings throughout the code, everything is organized here.

---

### 📁 **core/** - The Brain

#### **travel_planner.py** - The Orchestrator
```python
class TravelPlanner:
    def __init__(self):
        # Sets up all the agents
        
    def generate_trip_plan(self, trip_details):
        # Coordinates all agents to create complete plan
```

**What it does:**
- Manages all four AI agents
- Coordinates the trip planning process
- Combines results from all agents
- Creates the final downloadable trip plan

**Process Flow:**
1. Takes user input (destination, budget, interests, etc.)
2. Runs the Flight Agent
3. Runs the Hotel Agent  
4. Runs the Attraction Agent
5. Runs the Summary Agent with all previous results
6. Packages everything into a complete trip plan

**For Beginners:**
Think of this as the "project manager" who coordinates all the specialists to deliver a complete travel plan.

---

### 📁 **ui/** - The User Interface

#### **styles.py** - The Designer
```python
def apply_custom_styles():
    # Applies CSS styling to make the app look good
    
def render_header():
    # Shows the main title and subtitle
```

**What it does:**
- Makes the app look attractive with CSS styling
- Defines colors, fonts, and layout
- Creates the main header with title and subtitle

#### **forms.py** - The Input Handler
```python
def render_sidebar():
    # Creates the configuration sidebar
    
def render_trip_form():
    # Creates the main trip planning form
```

**What it does:**
- Creates all the input forms (text boxes, dropdowns, buttons)
- Handles the sidebar with AI model selection
- Collects user trip preferences and details

#### **display.py** - The Results Presenter
```python
def display_flight_info(flight_result, flight_error):
    # Shows flight results in a nice format
    
def display_example_content():
    # Shows sample content when app first loads
```

**What it does:**
- Displays results from each AI agent
- Formats the output in attractive cards
- Shows example content when the app first loads
- Handles error display if something goes wrong

**For Beginners:**
The UI folder is like the "interior design" of the app - it makes everything look good and easy to use.

---

## How Everything Works Together

### 🔄 **The Complete Flow:**

1. **User Opens App** (`main.py`)
   - Streamlit starts the web server
   - UI components load (header, forms, styling)

2. **User Fills Form** (`ui/forms.py`)
   - Origin/destination cities
   - Trip duration and budget
   - Travel interests/preferences

3. **User Clicks "Tune My Travel"** (`main.py`)
   - Form data gets collected
   - `process_trip_planning()` function starts

4. **Travel Planner Initializes** (`core/travel_planner.py`)
   - Creates all four AI agents
   - Sets up AI model connection

5. **Agents Run in Sequence:**
   - **Flight Agent** → Gets flight options
   - **Hotel Agent** → Gets accommodation options  
   - **Attraction Agent** → Gets activity suggestions
   - **Summary Agent** → Combines everything into itinerary

6. **Results Display** (`ui/display.py`)
   - Shows results in organized tabs
   - Provides download button for complete plan

### 🧠 **LangChain's Role:**
```python
# LangChain simplifies AI communication:
model = ChatOpenAI(...)  # Connect to AI
response = model.invoke(prompt)  # Send prompt, get response
```

LangChain handles:
- Connecting to different AI providers (OpenAI, Anthropic, Google)
- Managing conversation context
- Formatting prompts and responses
- Error handling for AI communications

### 🎨 **Streamlit's Role:**
```python
# Streamlit makes web development easy:
st.text_input("Enter city")     # Creates text input box
st.button("Submit")             # Creates clickable button
st.markdown(result)             # Displays formatted text
```

Streamlit handles:
- Creating the web interface
- Managing user interactions
- Displaying dynamic content
- Running the web server

## Key Concepts for Beginners

### 🤖 **What are AI Agents?**
An "agent" is an AI system designed for a specific task. Instead of one general AI trying to do everything, we have specialists:
- Like having separate experts for flights, hotels, and activities
- Each has specific instructions (system prompts) for their specialty
- They can focus and provide better, more targeted advice

### 📦 **What are Python Modules?**
- **Module**: A Python file containing related functions and classes
- **Package**: A folder containing multiple related modules
- **Import**: Bringing functions from other files into your current file

Example:
```python
from agents import create_flight_agent  # Import specific function
from ui import render_header            # Import from ui package
```

### 🔗 **What are System Prompts?**
Instructions that tell the AI how to behave:
```python
system_prompt = """You are an AI agent specializing in finding flight information.
Your task is to provide realistic flight options...
Include details such as: airline options, flight times, price ranges..."""
```

This is like giving detailed job instructions to an employee.

### 🎨 **What is CSS Styling?**
CSS makes websites look good:
```css
.agent-card {
    background-color: #f0f7ff;  /* Light blue background */
    border-radius: 10px;        /* Rounded corners */
    padding: 20px;              /* Space inside the card */
}
```

## Running the Application

### 📋 **Prerequisites:**
```bash
pip install streamlit langchain-openai openai httpx
```

### 🚀 **Start the App:**
```bash
cd src
streamlit run main.py
```

### 🌐 **Access the App:**
- Open your web browser
- Go to `http://localhost:8501`
- Fill in your trip details
- Click "Tune My Travel"
- View your personalized itinerary!

## Troubleshooting for Beginners

### 🔧 **Common Issues:**

1. **Import Errors:**
   - Make sure you're in the `src` directory
   - Check that all `__init__.py` files exist

2. **AI Model Errors:**
   - Verify API keys in `config/settings.py`
   - Check internet connection

3. **Streamlit Issues:**
   - Try different port: `streamlit run main.py --server.port 8502`
   - Clear cache: `streamlit cache clear`

## Next Steps for Learning

1. **Experiment**: Try modifying the interest options in `config/settings.py`
2. **Customize**: Change the styling in `ui/styles.py`
3. **Extend**: Add a new agent for transportation or restaurants
4. **Learn**: Study how each agent's system prompt affects its responses

Remember: Programming is like learning a language - start with understanding the basic structure, then gradually explore each component!