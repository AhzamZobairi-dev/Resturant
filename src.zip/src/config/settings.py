"""
Configuration module for the Travel Planner application.
Contains model setup and configuration settings.
"""

from langchain_openai import ChatOpenAI
import httpx
from openai import OpenAI


def get_eli_chat_model(temperature: float = 0.0) -> ChatOpenAI:
    """Create and configure the chat model instance."""
    # Create an instance of the OpenAI client
    http_client = httpx.Client(verify=False)
    client = OpenAI(
        api_key="sk-U0j3wCTfzxbPPxEZKQDE2g",
        base_url="https://genailab.tcs.in",
        http_client=http_client,
    )
    # Create an instance of ChatOpenAI
    
    llm = ChatOpenAI(
        base_url="https://genailab.tcs.in",
        model="azure_ai/genailab-maas-DeepSeek-V3-0324",
        api_key="sk-U0j3wCTfzxbPPxEZKQDE2g",
        http_client=http_client
    )

    # Now we plug the OpenAI client into our langchain-openai interface
    llm.client = client.chat.completions
    return llm


# Model configuration
MODEL_NAME = "DeepSeek-V3-0324"

# Model type mappings for UI
MODEL_TYPE_MAP = {
    "Claude (Anthropic)": "claude",
    "GPT-4o (OpenAI)": "openai",
    "Gemini 1.5 (Google)": "gemini"
}

# Available model options for UI
MODEL_OPTIONS = ["Claude (Anthropic)", "GPT-4o (OpenAI)", "Gemini 1.5 (Google)"]

# Interest options for trip planning
INTEREST_OPTIONS = [
    "Heritage & Culture", 
    "Nature Escapes", 
    "Taste the World", 
    "Shop & Stroll", 
    "Museums & Galleries", 
    "Rest & Rejuvenate", 
    "High-Energy Activities"
]