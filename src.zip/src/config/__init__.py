"""
Configuration package for the Travel Planner application.
"""

from .settings import (
    get_eli_chat_model,
    MODEL_NAME,
    MODEL_TYPE_MAP,
    MODEL_OPTIONS,
    INTEREST_OPTIONS
)

__all__ = [
    'get_eli_chat_model',
    'MODEL_NAME',
    'MODEL_TYPE_MAP', 
    'MODEL_OPTIONS',
    'INTEREST_OPTIONS'
]