"""
Core TravelPlanner class that coordinates all agents for trip planning.
"""

from typing import List, Dict, Any
from agents import (
    create_flight_agent,
    create_hotel_agent, 
    create_attraction_agent,
    create_summary_agent
)
from config import MODEL_NAME


class TravelPlanner:
    """Main class that coordinates all agents for trip planning"""
    
    def __init__(self):
        self.model_name = MODEL_NAME
        
        # Initialize agents
        self.flight_agent = create_flight_agent()
        self.hotel_agent = create_hotel_agent()
        self.attraction_agent = create_attraction_agent()
        self.summary_agent = create_summary_agent()
        
    def create_base_prompt(self, trip_details: Dict[str, Any]) -> str:
        """Create a base prompt with trip details"""
        return f"""
        Plan a trip with the following details:
        - Origin: {trip_details['origin']}
        - Destination: {trip_details['destination']}
        - Trip Duration: {trip_details["duration"]} days
        - Cost Limit: {trip_details['cost']}
        - Interests: {', '.join(trip_details['interests'])}
        """
    
    def run_flight_agent(self, base_prompt: str) -> str:
        """Run the Flight Finder agent"""
        flight_prompt = base_prompt + "\nFind flight options for this trip between the origin and destination."
        return self.flight_agent.run(flight_prompt)
    
    def run_hotel_agent(self, base_prompt: str, destination: str, budget: str, duration: str) -> str:
        """Run the Hotel Explorer agent"""
        hotel_prompt = base_prompt + f"\nFind hotel options in {destination} that fit the cost level of {budget} and duration: {duration}."
        return self.hotel_agent.run(hotel_prompt)
    
    def run_attraction_agent(self, base_prompt: str, destination: str, interests: List[str]) -> str:
        """Run the Attraction Scout agent"""
        attraction_prompt = base_prompt + f"\nFind interesting attractions and activities in {destination} that match these interests: {', '.join(interests)}."
        return self.attraction_agent.run(attraction_prompt)
    
    def run_summary_agent(self, base_prompt: str, flight_result: str, hotel_result: str, attraction_result: str) -> str:
        """Run the Trip Summarizer agent"""
        summary_prompt = f"""
        {base_prompt}
        
        Based on the following information, create a comprehensive day-by-day trip plan:
        
        FLIGHT INFORMATION:
        {flight_result}
        
        HOTEL INFORMATION:
        {hotel_result}
        
        ATTRACTIONS AND ACTIVITIES:
        {attraction_result}
        """
        return self.summary_agent.run(summary_prompt)
    
    def generate_trip_plan(self, trip_details: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a complete trip plan using all agents"""
        base_prompt = self.create_base_prompt(trip_details)
        
        # Run all agents
        flight_result = self.run_flight_agent(base_prompt)
        hotel_result = self.run_hotel_agent(base_prompt, trip_details['destination'], trip_details['cost'], trip_details["duration"])
        attraction_result = self.run_attraction_agent(base_prompt, trip_details['destination'], trip_details['interests'])
        summary_result = self.run_summary_agent(base_prompt, flight_result, hotel_result, attraction_result)
        
        # Create trip plan text for download
        trip_plan_text = f"""
        # YOUR TRIP PLAN: {trip_details['origin']} to {trip_details['destination']}
        
        ## Trip Details
        - **Origin**: {trip_details['origin']}
        - **Destination**: {trip_details['destination']}
        - **Duration**: {trip_details["duration"]} days
        - **Cost**: {trip_details['cost']}
        - **Interests**: {', '.join(trip_details['interests'])}
        
        ## Flight Information
        {flight_result}
        
        ## Accommodation Information
        {hotel_result}
        
        ## Attractions and Activities
        {attraction_result}
        
        ## Complete Day-by-Day Itinerary
        {summary_result}
        """
        
        # Return all results
        return {
            'flight_result': flight_result,
            'hotel_result': hotel_result,
            'attraction_result': attraction_result,
            'summary_result': summary_result,
            'trip_plan_text': trip_plan_text,
            'errors': {
                'flight_error': self.flight_agent.error,
                'hotel_error': self.hotel_agent.error,
                'attraction_error': self.attraction_agent.error,
                'summary_error': self.summary_agent.error
            }
        }