"""
Core package for the Travel Planner application.
"""

from .travel_planner import TravelPlanner

__all__ = ['TravelPlanner']