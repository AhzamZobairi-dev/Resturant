"""
Form components for the Travel Planner UI.
"""

import streamlit as st
from config import MODEL_OPTIONS, MODEL_TYPE_MAP, INTEREST_OPTIONS


def render_sidebar():
    """Render the sidebar with configuration options and help text"""
    with st.sidebar:
        st.header("Configuration")
        
        model_type = st.radio(
            "Select AI Model",
            options=MODEL_OPTIONS,
            index=0
        )
        
        # Display appropriate key input field
        if model_type == "Claude (Anthropic)":
            api_key = st.text_input("Enter Anthropic API Key", type="password")
            api_info = "You'll need an Anthropic API key with access to Claude 3.7 Sonnet"
        elif model_type == "GPT-4o (OpenAI)":
            api_key = st.text_input("Enter OpenAI API Key", type="password")
            api_info = "You'll need an OpenAI API key with access to GPT-4o"
        else:  # Gemini
            api_key = st.text_input("Enter Google AI API Key", type="password")
            api_info = "You'll need a Google AI API key with access to Gemini 1.5"
            
        st.info(api_info)
        
        st.markdown("---")
        st.markdown("### How it works")
        st.markdown("""
        This app uses multiple AI agents to plan your trip:
        1. **Flight Finder** searches for flights
        2. **Hotel Explorer** finds accommodations
        3. **Attraction Scout** discovers points of interest
        4. **Trip Summarizer** combines all information into a cohesive plan
        """)
        
        return api_key, MODEL_TYPE_MAP[model_type]


def render_trip_form():
    """Render the form for trip details input"""
    with st.form("trip_details_form"):
        st.header("Enter Your Trip Details")
        col1, col2 = st.columns(2)
        
        with col1:
            origin = st.text_input("Origin City", "New York")
            destination = st.text_input("Destination City", "Tokyo")
            
        with col2:
            duration = st.text_input("Trip Duration (days)", "7")
            cost = st.text_input("Cost/Budget", "1000000")
        
        interests = st.multiselect(
            "Preferences",
            options=INTEREST_OPTIONS
        )
        
        submitted = st.form_submit_button("Tune My Travel")
        
        if submitted:
            return {
                'origin': origin,
                'destination': destination,
                "duration": duration,
                "cost": cost,
                'interests': interests,
                'submitted': True
            }
        return {'submitted': False}