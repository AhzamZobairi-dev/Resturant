"""
Styling and header components for the Travel Planner UI.
"""

import streamlit as st


def apply_custom_styles():
    """Apply custom CSS styles to the Streamlit app"""
    st.markdown("""
    <style>
        .main {
            padding: 2rem;
        }
        .block-container {
            padding-top: 2rem;
            padding-bottom: 2rem;
        }
        h1, h2, h3 {
            color: #1E3A8A;
        }
        .agent-card {
            background-color: #f0f7ff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            border-left: 5px solid #3b82f6;
        }
        .summary-card {
            background-color: #f0fff4;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            border-left: 5px solid #10b981;
        }
    </style>
    """, unsafe_allow_html=True)


def render_header():
    """Render the app header and title"""
    st.title("Smart Itinerary")
    st.markdown("Plan Less, Explore your Travel dreams with AI!")