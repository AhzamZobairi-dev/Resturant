"""
Display components for showing results in the Travel Planner UI.
"""

import streamlit as st


def display_flight_info(flight_result, flight_error):
    """Display flight information tab"""
    st.markdown(f"<div class='agent-card'><h3>🛫 Flight Finder</h3>", unsafe_allow_html=True)
    if flight_error:
        st.error(f"Error: {flight_error}")
    else:
        st.markdown(flight_result)
    st.markdown("</div>", unsafe_allow_html=True)


def display_hotel_info(hotel_result, hotel_error):
    """Display hotel information tab"""
    st.markdown(f"<div class='agent-card'><h3>🏨 Hotel Explorer</h3>", unsafe_allow_html=True)
    if hotel_error:
        st.error(f"Error: {hotel_error}")
    else:
        st.markdown(hotel_result)
    st.markdown("</div>", unsafe_allow_html=True)


def display_attraction_info(attraction_result, attraction_error):
    """Display attraction information tab"""
    st.markdown(f"<div class='agent-card'><h3>🏛️ Attraction Scout</h3>", unsafe_allow_html=True)
    if attraction_error:
        st.error(f"Error: {attraction_error}")
    else:
        st.markdown(attraction_result)
    st.markdown("</div>", unsafe_allow_html=True)


def display_trip_summary(summary_result, summary_error):
    """Display trip summary tab"""
    st.markdown(f"<div class='summary-card'><h3>📝 Trip Summarizer</h3>", unsafe_allow_html=True)
    if summary_error:
        st.error(f"Error: {summary_error}")
    else:
        st.markdown(summary_result)
    st.markdown("</div>", unsafe_allow_html=True)


def display_example_content():
    """Display example content when app first loads"""
    st.info("Fill in your trip details and click 'Plan My Trip' to get started!")
    
    st.markdown("### Sample Trip Plan")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("#### Flight Options")
        st.markdown("• Multiple airlines with various departure times\n• Direct and connecting flight options\n• Price ranges for economy and business class")
    with col2:
        st.markdown("#### Hotel Recommendations")
        st.markdown("• Options for your chosen budget level\n• Best neighborhoods to stay in\n• Amenities and nearby attractions")
    with col3:
        st.markdown("#### Must-See Attractions")
        st.markdown("• Top-rated sights and experiences\n• Hidden gems and local favorites\n• Activities matched to your interests")