"""
UI package for the Travel Planner application.
"""

from .styles import apply_custom_styles, render_header
from .forms import render_sidebar, render_trip_form
from .display import (
    display_flight_info,
    display_hotel_info,
    display_attraction_info,
    display_trip_summary,
    display_example_content
)

__all__ = [
    'apply_custom_styles',
    'render_header',
    'render_sidebar', 
    'render_trip_form',
    'display_flight_info',
    'display_hotel_info',
    'display_attraction_info',
    'display_trip_summary',
    'display_example_content'
]