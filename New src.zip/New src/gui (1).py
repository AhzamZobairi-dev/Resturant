import streamlit as st
import datetime
import os
from travel import TravelPlanner

# Set page configuration
st.set_page_config(
    page_title="AI Itinerary Planner",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Custom CSS for modern, sleek design
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    * {
        font-family: 'Inter', sans-serif;
    }
    
    .main {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        padding: 0;
    }
    
    .block-container {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        margin: 2rem auto;
        padding: 2rem;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        max-width: 1200px;
    }
    
    .main-header {
        text-align: center;
        background: linear-gradient(135deg, #667eea, #764ba2);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-size: 3rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .sub-header {
        text-align: center;
        color: #6b7280;
        font-size: 1.2rem;
        margin-bottom: 2rem;
        font-weight: 400;
    }
    
    .section-header {
        color: #374151;
        font-size: 1.5rem;
        font-weight: 600;
        margin: 2rem 0 1rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 2px solid #e5e7eb;
    }
    
    .input-container {
        background: #f8fafc;
        border-radius: 15px;
        padding: 1.5rem;
        margin: 1rem 0;
        border: 1px solid #e2e8f0;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        transition: all 0.3s ease;
    }
    
    .input-container:hover {
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        transform: translateY(-2px);
    }
    
    .duration-display {
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
        padding: 1.5rem;
        border-radius: 15px;
        text-align: center;
        margin: 1rem 0;
        box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% { box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3); }
        50% { box-shadow: 0 8px 25px rgba(102, 126, 234, 0.5); }
        100% { box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3); }
    }
    
    .duration-number {
        font-size: 3rem;
        font-weight: 700;
        display: block;
    }
    
    .duration-text {
        font-size: 1.2rem;
        font-weight: 400;
        opacity: 0.9;
    }
    
    .generate-btn {
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
        border: none;
        padding: 1rem 2rem;
        border-radius: 50px;
        font-size: 1.2rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
        width: 100%;
        margin-top: 2rem;
    }
    
    .generate-btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 15px 30px rgba(102, 126, 234, 0.4);
    }
    
    .model-selector {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        border-radius: 15px;
        padding: 1.5rem;
        margin: 1rem 0;
        color: white;
        box-shadow: 0 8px 20px rgba(245, 87, 108, 0.3);
    }
    
    .api-key-container {
        background: #fef3c7;
        border: 2px solid #f59e0b;
        border-radius: 10px;
        padding: 1rem;
        margin-top: 1rem;
    }
    
    .stSelectbox > div > div {
        background: white;
        border-radius: 10px;
        border: 2px solid #e5e7eb;
        transition: all 0.3s ease;
    }
    
    .stSelectbox > div > div:focus-within {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    
    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea,
    .stNumberInput > div > div > input {
        border-radius: 10px;
        border: 2px solid #e5e7eb;
        transition: all 0.3s ease;
        padding: 0.75rem;
    }
    
    .stTextInput > div > div > input:focus,
    .stTextArea > div > div > textarea:focus,
    .stNumberInput > div > div > input:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    
    .stDateInput > div > div > input {
        border-radius: 10px;
        border: 2px solid #e5e7eb;
        transition: all 0.3s ease;
    }
    
    .warning-box {
        background: #fef2f2;
        border: 2px solid #f87171;
        border-radius: 10px;
        padding: 1rem;
        margin: 1rem 0;
        color: #dc2626;
    }
    
    .success-box {
        background: #f0fff4;
        border: 2px solid #22c55e;
        border-radius: 10px;
        padding: 1rem;
        margin: 1rem 0;
        color: #059669;
    }
    
    .feature-card {
        background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
        border-radius: 15px;
        padding: 1.5rem;
        margin: 1rem 0;
        text-align: center;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
    }
    
    .feature-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
    }
    
    .feature-icon {
        font-size: 2rem;
        margin-bottom: 0.5rem;
    }
    
    /* Hide Streamlit default elements */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    .stDeployButton {display: none;}
</style>
""", unsafe_allow_html=True)

# Title and header
def render_header():
    """Render the app header and title"""
    st.markdown('<h1 class="main-header">� AI Itinerary Planner</h1>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Let our intelligent agents craft your perfect travel experience</p>', unsafe_allow_html=True)

def render_model_selection():
    """Render the model selection section"""
    model_options = {
        "GPT-4": "gpt-4",
        "GPT-4 Turbo": "gpt-4-turbo",
        "Claude 3.5 Sonnet": "claude-3-5-sonnet",
        "Claude 3 Opus": "claude-3-opus", 
        "Gemini Pro": "gemini-pro",
        "Gemini 1.5 Pro": "gemini-1.5-pro"
    }
    
    # Initialize session state for model and API key if not exists
    if 'selected_model' not in st.session_state:
        st.session_state.selected_model = "GPT-4"
    if 'api_key' not in st.session_state:
        st.session_state.api_key = ""
    
    st.markdown("### 🤖 **AI Model Configuration**")
    
    # Model selection dropdown with session state
    selected_model = st.selectbox(
        "Choose your AI model:",
        options=list(model_options.keys()),
        index=list(model_options.keys()).index(st.session_state.selected_model) if st.session_state.selected_model in model_options.keys() else 0,
        help="Select the AI model that will power your travel planning",
        key="model_selector"
    )
    
    # Update session state
    st.session_state.selected_model = selected_model
    
    # API Key input with validation
    st.markdown("### 🔐 **API Key**")
    api_key = st.text_input(
        f"Enter your {selected_model} API Key:",
        type="password",
        placeholder="sk-... or your API key",
        help="Your API key is required to access the AI model. It will not be stored.",
        key="api_key_input",
        value=st.session_state.api_key
    )
    
    # Update session state
    st.session_state.api_key = api_key
    
    if not api_key:
        st.warning("⚠️ Please provide your API key to continue")
    else:
        st.success("✅ API key provided")
    
    st.divider()
    
    return selected_model, model_options[selected_model], api_key

def render_trip_form():
    """Render the main trip planning form"""
    st.markdown('<h2 class="section-header">✈️ Trip Details</h2>', unsafe_allow_html=True)
    
    # Initialize session state for form fields
    if 'origin' not in st.session_state:
        st.session_state.origin = ""
    if 'destination' not in st.session_state:
        st.session_state.destination = ""
    if 'departure_date' not in st.session_state:
        st.session_state.departure_date = datetime.date.today() + datetime.timedelta(days=30)
    if 'return_date' not in st.session_state:
        st.session_state.return_date = datetime.date.today() + datetime.timedelta(days=37)
    if 'budget_level' not in st.session_state:
        st.session_state.budget_level = "Moderate"
    if 'travelers' not in st.session_state:
        st.session_state.travelers = 2
    if 'side_quests' not in st.session_state:
        st.session_state.side_quests = ""
    
    with st.form("itinerary_form"):
        # Travel locations
        st.markdown("### 📍 **Destinations**")
        col1, col2 = st.columns(2)
        
        with col1:
            origin = st.text_input(
                "🛫 Origin City",
                placeholder="e.g., New York, London, Tokyo",
                help="Enter your departure city",
                key="origin_input",
                value=st.session_state.origin
            )
        
        with col2:
            destination = st.text_input(
                "🏙️ Destination City", 
                placeholder="e.g., Paris, Bali, Rome",
                help="Enter your destination city",
                key="destination_input",
                value=st.session_state.destination
            )
        
        st.divider()
        
        # Travel dates
        st.markdown("### 📅 **Travel Dates**")
        col1, col2 = st.columns(2)
        
        today = datetime.date.today()
        with col1:
            departure_date = st.date_input(
                "🛫 Departure Date",
                value=st.session_state.departure_date,
                min_value=today,
                help="Select your departure date",
                key="departure_date_input"
            )
        
        with col2:
            return_date = st.date_input(
                "🛬 Return Date",
                value=st.session_state.return_date,
                min_value=departure_date,
                help="Select your return date",
                key="return_date_input"
            )
        
        # Trip duration display
        if departure_date and return_date:
            duration = (return_date - departure_date).days
            st.markdown(f'''
            <div class="duration-display">
                <span class="duration-number">{duration}</span>
                <span class="duration-text">Days of Adventure</span>
            </div>
            ''', unsafe_allow_html=True)
        
        st.divider()
        
        # Budget and travelers
        st.markdown("### 💰 **Budget & Group**")
        col1, col2 = st.columns(2)
        
        with col1:
            budget_level = st.selectbox(
                "💸 Budget Level",
                options=["Low", "Economy", "Moderate", "Luxury", "Ultra Richie Rich"],
                index=["Low", "Economy", "Moderate", "Luxury", "Ultra Richie Rich"].index(st.session_state.budget_level),
                help="Select your preferred budget range",
                key="budget_input"
            )
        
        with col2:
            travelers = st.number_input(
                "👥 Number of Travelers",
                min_value=1,
                max_value=20,
                value=st.session_state.travelers,
                help="How many people will be traveling?",
                key="travelers_input"
            )
        
        st.divider()
        
        # User side quests
        st.markdown("### 🎯 **Side Quests & Preferences**")
        side_quests = st.text_area(
            "🌟 Additional Activities or Special Requests",
            placeholder="e.g., Visit local markets, try authentic cuisine, photography spots, adventure activities, cultural experiences...",
            height=100,
            help="Tell us about any specific activities, experiences, or preferences you have",
            key="side_quests_input",
            value=st.session_state.side_quests
        )
        
        # Submit button
        submitted = st.form_submit_button("🚀 Generate My Dream Itinerary", use_container_width=True)
        
        if submitted:
            # Update session state
            st.session_state.origin = origin
            st.session_state.destination = destination
            st.session_state.departure_date = departure_date
            st.session_state.return_date = return_date
            st.session_state.budget_level = budget_level
            st.session_state.travelers = travelers
            st.session_state.side_quests = side_quests
            
            return {
                'origin': origin,
                'destination': destination,
                'start_date': departure_date,
                'end_date': return_date,
                'budget': budget_level,
                'travelers': int(travelers),
                'interests': side_quests if side_quests else "General sightseeing and local experiences",
                'submitted': True
            }
    
    return {'submitted': False}

# Display flight information
def display_flight_info(flight_result, flight_error):
    """Display flight information tab"""
    st.markdown(f"<div class='agent-card'><h3>🛫 Flight Finder</h3>", unsafe_allow_html=True)
    if flight_error:
        st.error(f"Error: {flight_error}")
    else:
        st.markdown(flight_result)
    st.markdown("</div>", unsafe_allow_html=True)

# Display hotel information
def display_hotel_info(hotel_result, hotel_error):
    """Display hotel information tab"""
    st.markdown(f"<div class='agent-card'><h3>🏨 Hotel Explorer</h3>", unsafe_allow_html=True)
    if hotel_error:
        st.error(f"Error: {hotel_error}")
    else:
        st.markdown(hotel_result)
    st.markdown("</div>", unsafe_allow_html=True)

# Display attraction information
def display_attraction_info(attraction_result, attraction_error):
    """Display attraction information tab"""
    st.markdown(f"<div class='agent-card'><h3>🏛️ Attraction Scout</h3>", unsafe_allow_html=True)
    if attraction_error:
        st.error(f"Error: {attraction_error}")
    else:
        st.markdown(attraction_result)
    st.markdown("</div>", unsafe_allow_html=True)

# Display trip summary
def display_trip_summary(summary_result, summary_error):
    """Display trip summary tab"""
    st.markdown(f"<div class='summary-card'><h3>📝 Complete Itinerary</h3>", unsafe_allow_html=True)
    if summary_error:
        st.error(f"Error: {summary_error}")
    else:
        st.markdown(summary_result)
    st.markdown("</div>", unsafe_allow_html=True)

# Display example content when app first loads
def display_example_content():
    """Display feature showcase when app first loads"""
    st.markdown("### ✨ **What Makes Our AI Planner Special?**")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown('''
        <div class="feature-card">
            <div class="feature-icon">🤖</div>
            <h4>Smart AI Agents</h4>
            <p>Multiple specialized agents work together to plan every aspect of your trip</p>
        </div>
        ''', unsafe_allow_html=True)
    
    with col2:
        st.markdown('''
        <div class="feature-card">
            <div class="feature-icon">🎯</div>
            <h4>Personalized Planning</h4>
            <p>Tailored recommendations based on your budget, interests, and travel style</p>
        </div>
        ''', unsafe_allow_html=True)
    
    with col3:
        st.markdown('''
        <div class="feature-card">
            <div class="feature-icon">📋</div>
            <h4>Complete Itineraries</h4>
            <p>Day-by-day plans with flights, hotels, attractions, and local experiences</p>
        </div>
        ''', unsafe_allow_html=True)
    
    st.markdown("---")
    st.info("👆 Configure your AI model and fill in your trip details above to get started!")

# Process trip planning
def process_trip_planning(api_key, model_type, trip_details):
    """Process trip planning with all agents"""
    if not api_key:
        st.error("🔑 Please enter your API key above to continue")
        return
    
    if not all([trip_details['origin'], trip_details['destination']]):
        st.error("📍 Please fill in both origin and destination cities")
        return
    
    try:
        # Initialize the travel planner
        planner = TravelPlanner(api_key, model_type)
        
        # Show enhanced progress indicator
        progress_placeholder = st.empty()
        with progress_placeholder.container():
            st.markdown('''
            <div class="success-box">
                🚀 <strong>Launching AI Agents...</strong><br>
                Our intelligent agents are working together to craft your perfect itinerary!
            </div>
            ''', unsafe_allow_html=True)
        
        # Generate the trip plan
        results = planner.generate_trip_plan(trip_details)
        
        # Clear progress indicator
        progress_placeholder.empty()
        
        # Success message
        st.markdown('''
        <div class="success-box">
            ✅ <strong>Your itinerary is ready!</strong> Explore the tabs below to see your personalized travel plan.
        </div>
        ''', unsafe_allow_html=True)
        
        # Display results in tabs
        st.markdown('<h2 class="section-header">🗺️ Your Personalized Travel Plan</h2>', unsafe_allow_html=True)
        
        tabs = st.tabs(["✈️ Flights", "🏨 Hotels", "🎯 Attractions", "📋 Complete Itinerary"])
        
        with tabs[0]:
            display_flight_info(results['flight_result'], results['errors']['flight_error'])
        
        with tabs[1]:
            display_hotel_info(results['hotel_result'], results['errors']['hotel_error'])
        
        with tabs[2]:
            display_attraction_info(results['attraction_result'], results['errors']['attraction_error'])
        
        with tabs[3]:
            display_trip_summary(results['summary_result'], results['errors']['summary_error'])
        
        # Enhanced download section
        st.markdown("---")
        st.markdown("### 📥 **Download Your Itinerary**")
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.info("💡 Save your complete travel plan as a markdown file for easy access during your trip!")
        
        with col2:
            st.download_button(
                label="📄 Download Complete Plan",
                data=results['trip_plan_text'],
                file_name=f"itinerary_{trip_details['destination'].replace(' ', '_')}_{trip_details['start_date'].strftime('%Y-%m-%d')}.md",
                mime="text/markdown",
                use_container_width=True
            )
        
    except Exception as e:
        st.markdown(f'''
        <div class="warning-box">
            ❌ <strong>Oops! Something went wrong:</strong><br>
            {str(e)}<br><br>
            Please check your API key and try again.
        </div>
        ''', unsafe_allow_html=True)

# Main app function
def main():
    """Main application function"""
    render_header()
    
    # Model selection section
    selected_model_name, model_type, api_key = render_model_selection()
    
    # Trip form section
    trip_details = render_trip_form()
    
    # Process or show example content
    if trip_details['submitted']:
        process_trip_planning(api_key, model_type, trip_details)
    else:
        display_example_content()
    
    # Add footer
    st.markdown("---")
    st.markdown("<p style='text-align: center; color: #9ca3af; font-size: 0.9rem;'>🌍 AI Itinerary Planner | Powered by Intelligent Travel Agents</p>", unsafe_allow_html=True)

if __name__ == "__main__":
    main()